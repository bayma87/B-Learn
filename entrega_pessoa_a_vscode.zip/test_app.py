import unittest
from app import app

class TestApp(unittest.TestCase):
    def setUp(self):
        # Configura o cliente de testes do Flask
        self.client = app.test_client()
        self.client.testing = True

    def test_gatilhos_endpoint(self):
        # Testa a rota /api/impacto/gatilhos (Testes A)
        response = self.client.get('/api/impacto/gatilhos')
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertIsInstance(data, list)
        if len(data) > 0:
            self.assertIn('tipo_evento', data[0])
            self.assertIn('acao_sugerida', data[0])

    def test_comparacao_endpoint(self):
        # Testa a rota /api/impacto/comparacao (Testes A)
        response = self.client.get('/api/impacto/comparacao')
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertIn('variacao_percentual', data)
        self.assertTrue(data['variacao_percentual'] < 0) # Neste exemplo estático a variação é negativa

if __name__ == '__main__':
    unittest.main()
