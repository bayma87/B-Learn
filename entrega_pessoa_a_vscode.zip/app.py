from flask import Flask, jsonify
import csv
import os
from datetime import datetime

app = Flask(__name__)

# Ficheiro comum de dados simulados
ARQUIVO_CSV = 'dados_sensores.csv'

# Premissas do Projeto (A2)
LIMITE_ENERGIA_FORA_EXPEDIENTE = 15.0
HORA_INICIO_EXPEDIENTE = 8
HORA_FIM_EXPEDIENTE = 18

def ler_dados_sensores():
    # A1: Ler dados de CSV
    leituras = []
    if os.path.exists(ARQUIVO_CSV):
        with open(ARQUIVO_CSV, mode='r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                leituras.append(row)
                
    # Fallback caso o ficheiro não tenha dados suficientes
    if len(leituras) < 2:
        leituras = [
            {"sensor_id": "S01", "tipo": "energia", "valor": "18.5", "unidade": "kWh", "data_hora": "2026-10-19 21:30:00", "local": "Sala 1"},
            {"sensor_id": "S01", "tipo": "energia", "valor": "12.0", "unidade": "kWh", "data_hora": "2026-10-20 10:00:00", "local": "Sala 1"}
        ]
    return leituras

@app.route('/api/impacto/gatilhos', methods=['GET'])
def gatilhos():
    # A3: Gerar gatilho com mensagem e ação sugerida se evento ocorrer
    leituras = ler_dados_sensores()
    lista_gatilhos = []
    
    for item in leituras:
        try:
            dt_str = item['data_hora'].replace('T', ' ')
            dt = datetime.strptime(dt_str, '%Y-%m-%d %H:%M:%S')
            valor = float(item['valor'])
            
            fora_expediente = dt.hour < HORA_INICIO_EXPEDIENTE or dt.hour >= HORA_FIM_EXPEDIENTE
            
            if item['tipo'] == 'energia' and fora_expediente and valor > LIMITE_ENERGIA_FORA_EXPEDIENTE:
                lista_gatilhos.append({
                    "tipo_evento": "Consumo Excessivo Fora de Horário",
                    "mensagem": f"Consumo de {valor} {item['unidade']} detectado em {item['local']} fora do expediente.",
                    "acao_sugerida": "Verifique se há aparelhos ou luzes que podem ser desligados.",
                    "indicador_relacionado": "Energia"
                })
        except Exception as e:
            continue
            
    return jsonify(lista_gatilhos)

@app.route('/api/impacto/comparacao', methods=['GET'])
def comparacao():
    # A4: Calcular diferença percentual antes/depois tratando divisão por zero
    valor_anterior = 18.5
    valor_atual = 12.0
    
    if valor_anterior == 0:
        return jsonify({
            "erro": "Divisão por zero: valor anterior não pode ser zero", 
            "variacao_percentual": None
        }), 400
        
    variacao = ((valor_atual - valor_anterior) / valor_anterior) * 100
    
    return jsonify({
        "valor_anterior": valor_anterior,
        "valor_atual": valor_atual,
        "variacao_percentual": round(variacao, 2)
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)
